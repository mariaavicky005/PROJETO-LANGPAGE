var swiper = new Swiper('.mySwiper', {
    slidesPerView: 3,/* os slides ficam um do lado do outro bem coladiho*/
    spaceBetween: 10,/* os slides ganham bordas maiores deixando assim de ficarem colados*/
    pagination: { /* trocou de slide*/
      el: '.swiper-pagination',
      clickable: true,    
    },
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    breakpoints: {
      320: {
        slidesPerView: 1, /* apareceu os potinhos indicando a quantidade de imagens*/
      },
      768: {
        slidesPerView: 2,
        spaceBetween: 20,
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
    },
  });